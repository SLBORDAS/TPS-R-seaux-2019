# B2-Reseau-2018

Vous trouverez ici toutes les ressources liées au cours de réseau des B2 promo 2017.   

Les supports de cours dans [cours](./cours) et les TPs dans [tp](./tp).

L'hébergement sur Github n'est pas un hasard, vous pouvez participer à la rédaction des pages en me faisait un Pull Request (on peut en parler si vous voulez).  